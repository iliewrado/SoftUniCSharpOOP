﻿namespace BirthdayCelebrations
{
    interface IRobots
    {
        string Model { get; set; }
    }
}

﻿namespace Shapes
{
    public interface IDrawable
    {
        public abstract void Draw();
    }
}

﻿namespace BorderControl
{
    public interface IIdentifiable
    {
        public string Id { get; set; }
    }
}

﻿namespace Telephony
{
    public interface IBrowsing
    {
        void Browsing(string url);
    }
}

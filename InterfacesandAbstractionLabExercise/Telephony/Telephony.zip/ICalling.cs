﻿namespace Telephony
{
    interface ICalling
    {
        void Calling(string phoneNumber);
    }
}

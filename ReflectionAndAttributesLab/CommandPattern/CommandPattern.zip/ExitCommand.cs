﻿using CommandPattern.Core.Contracts;

namespace CommandPattern
{
    public class ExitCommand : ICommand
    {
        public string Execute(string[] args)
        {
            return null;
        }
    }
}

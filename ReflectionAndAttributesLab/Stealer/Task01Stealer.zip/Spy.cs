﻿using System;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        public string StealFieldInfo(string investigatedClass, params string[] requestedFields)
        {
            Type classType = Type.GetType(investigatedClass);
            FieldInfo[] classFields = classType
                .GetFields(BindingFlags.Instance | BindingFlags.Static
                | BindingFlags.NonPublic | BindingFlags.Public);
            
            StringBuilder spy = new StringBuilder();

            object classInstance = Activator.CreateInstance(classType, null);

            spy.AppendLine($"Class under investigation: {investigatedClass}");

            foreach (FieldInfo field in classFields
                .Where(x => requestedFields.Contains(x.Name)))
            {
                spy.AppendLine($"{field.Name} = {field.GetValue(classInstance)}");
            }

            return spy.ToString();
        }
    }
}

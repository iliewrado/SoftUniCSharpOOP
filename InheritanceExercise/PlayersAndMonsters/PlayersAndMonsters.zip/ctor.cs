﻿namespace PlayersAndMonsters
{
    internal class ctor
    {
    }
}
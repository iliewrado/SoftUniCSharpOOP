﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    public class SoulMaster : Wizard
    {
        public SoulMaster(string usename, int level)
            :base(usename, level)
        {

        }
    }
}
